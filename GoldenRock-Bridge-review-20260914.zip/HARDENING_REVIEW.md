# Bridge hardening review — 2026-09-12

Status: partial implementation; NOT FOR FABRICATION. Not deployed.

Implemented in GoldenRockBridge.cs and compiled as GoldenRockBridge-hardened.dll:
- Explicit system, fixing-count and connection numeric input.
- OMEGA enum normalized; L three-point side uses backend top/bottom values.
- Connection values incompatible with the backend are rejected before sending.
- Explicit Yes confirmation before sending scan geometry.
- Closed-polyline restriction; unsupported blocks/ByBlock fail closed.
- Partial-height openings rejected; head/sill zones are not silently discarded.
- Requests complete before one drawing transaction, avoiding partial drawing on network failure.
- Unique run folders retain each segment input and response; complete.json marks completion.
- GRDETAILS requests the selected segment input JSON instead of silently using the last one.

API contract (current backend): POST /api/cladding/plan, JSON, units mm.
system: U | Z | OMEGA | L.
stone_fixing_type: U_channel | Z_bracket | Omega_bracket | L_bracket (and supported legacy fixing types).
bracket_layout.three_point_side: top | bottom; no Left/Right mapping is assumed.
connection.entry: rear | top_pin.
connection.support_face_from_wall_mm and stone_back_from_wall_mm: positive number or null.
Rear fixing: back = support + projection - penetration.
U support 110; U/Z/Omega projection 40; L projection 50; penetration 8 at 20mm, 14 at 30mm.
25mm or different connection dimensions remain unresolved by this contract.
Responses contain shop_drawing.panels, drawing_package, rfis and fabrication_released=false.
Successful HTTP or compilation does not establish structural approval.

Validation:
C# compilation against installed AutoCAD 2022 references: passed.
Python suite: 71 run, 63 passed, 8 failed. Failures include stale connection geometry expectations and drawing line-count expectations; unresolved, not hidden by skipping tests.
No live AutoCAD NETLOAD/GRSCAN test performed in this update.

Outstanding:
- Geometric rectangle validation, proper wall-derived envelope, UCS transforms, nonrectangular/partial-height openings and block traversal.
- C# geometry unit tests and live AutoCAD integration tests.
- Authentication for both website and bridge, session-isolated project storage, rate limits.
- Structural calculations with approved material/anchor/load inputs; warning text is not validation.
- Complete archival/error recovery for all legacy commands.
- CI and source/DLL reproducibility manifest.
- Deployment verification using served API/code rather than the static v1.5 footer (that footer was never updated and does not prove deployment failure).
Update 2026-09-14 (supersedes earlier validation counts):
71 Python tests passed, zero failures, using project venv and Poppler fixture.
Updated regression expectations reflect confirmed 8/14mm penetration and structural-wall reference; insulation does not add to wall-to-support distance.
Fixed non-U section reading a removed survey field; now reads connection support face.
Removed obsolete 20mm penetration note from U section.
GRSCAN now rejects non-rectangular/curved/rotated boundaries, non-World UCS, multiple wall boundaries and selection margins that differ from wall bounds.
C# rebuilt successfully against AutoCAD 2022. Live NETLOAD/GRSCAN not tested. Not deployed.
Outstanding limitations listed above still apply except test failures and rectangle/UCS validation addressed here.
