using System;
using System.Net;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Colors;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

public class GoldenRockBridge
{
    const string Host = "https://golden-rock-stone-ai-production.up.railway.app";
    static JavaScriptSerializer json = new JavaScriptSerializer() { MaxJsonLength = 20000000 };

    static string Call(string path, string body)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        var r = (HttpWebRequest)WebRequest.Create(Host + path);
        r.Timeout = 60000;
        if (body != null)
        {
            r.Method = "POST";
            r.ContentType = "application/json";
            var b = Encoding.UTF8.GetBytes(body);
            using (var s = r.GetRequestStream()) s.Write(b, 0, b.Length);
        }
        using (var response = r.GetResponse())
        using (var sr = new StreamReader(response.GetResponseStream()))
            return sr.ReadToEnd();
    }

    static string PluginFolder()
    {
        return Path.GetDirectoryName(typeof(GoldenRockBridge).Assembly.Location);
    }

    [CommandMethod("GRCONNECT")]
    public void Connect()
    {
        var e = AcApp.DocumentManager.MdiActiveDocument.Editor;
        try { e.WriteMessage("\nGolden Rock: " + Call("/health", null)); }
        catch (System.Exception ex) { e.WriteMessage("\nConnection failed: " + ex.Message); }
    }

    double Number(Editor e, string message)
    {
        var o = new PromptDoubleOptions(message) { AllowNegative = false, AllowZero = false };
        var r = e.GetDouble(o);
        if (r.Status != PromptStatus.OK) throw new System.Exception("Cancelled");
        return r.Value;
    }

    double ZeroNumber(Editor e, string message)
    {
        var o = new PromptDoubleOptions(message) { AllowNegative = false, AllowZero = true };
        var r = e.GetDouble(o);
        if (r.Status != PromptStatus.OK) throw new System.Exception("Cancelled");
        return r.Value;
    }

    double[] Numbers(Editor e, string message)
    {
        var o = new PromptStringOptions(message) { AllowSpaces = true };
        var r = e.GetString(o);
        if (r.Status != PromptStatus.OK) throw new System.Exception("Cancelled");
        var values = new List<double>();
        foreach (var part in r.StringResult.Split(','))
        {
            double v;
            if (!double.TryParse(part.Trim(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v) || double.IsNaN(v) || double.IsInfinity(v))
                throw new System.Exception("Enter numbers separated by commas.");
            values.Add(v);
        }
        return values.ToArray();
    }

    // Numeric prompt that accepts a project-confirmed default on Enter (shown in the message as "<default>"
    // by the caller). Still a real, visible value the drafter can override - never a silent assumption.
    double DefaultNumber(Editor e, string message, double def)
    {
        var o = new PromptDoubleOptions(message) { AllowNegative = false, AllowZero = true, DefaultValue = def, UseDefaultValue = true, AllowNone = true };
        var r = e.GetDouble(o);
        if (r.Status != PromptStatus.OK) throw new System.Exception("Cancelled");
        return r.Value;
    }

    // Resolves an entity's displayed color even when it is set ByLayer (the normal AutoCAD convention),
    // since GRSCAN's wall/opening detection is keyed on the color the drafter actually SEES on screen.
    static Color EffectiveColor(Transaction tr, Entity ent)
    {
        if (ent.Color.ColorMethod == ColorMethod.ByLayer)
        {
            var ltr = (LayerTableRecord)tr.GetObject(ent.LayerId, OpenMode.ForRead);
            return ltr.Color;
        }
        return ent.Color;
    }

    static bool SameColor(Color a, Color b)
    {
        if (a.ColorMethod == ColorMethod.ByAci && b.ColorMethod == ColorMethod.ByAci)
            return a.ColorIndex == b.ColorIndex;
        return a.ColorValue.ToArgb() == b.ColorValue.ToArgb();
    }

    // Shared: draw the nominal stone panels as closed polylines + preliminary note.
    // Used by GRWALL (manual entry) and GRIMPORT (loaded from the website's review JSON).
    void DrawPanels(Transaction tr, Database db, Editor e, Point3d origin, System.Collections.IEnumerable panels)
    {
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        if (!lt.Has("GR_PRELIM_STONE"))
        {
            lt.UpgradeOpen();
            var lr = new LayerTableRecord() { Name = "GR_PRELIM_STONE" };
            lt.Add(lr);
            tr.AddNewlyCreatedDBObject(lr, true);
        }
        var space = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);
        foreach (Dictionary<string, object> p in panels)
        {
            double x = Convert.ToDouble(p["x_mm"]), y = Convert.ToDouble(p["y_mm"]), pw = Convert.ToDouble(p["width_mm"]), ph = Convert.ToDouble(p["height_mm"]);
            var pl = new Polyline();
            pl.AddVertexAt(0, new Point2d(x, y), 0, 0, 0);
            pl.AddVertexAt(1, new Point2d(x + pw, y), 0, 0, 0);
            pl.AddVertexAt(2, new Point2d(x + pw, y + ph), 0, 0, 0);
            pl.AddVertexAt(3, new Point2d(x, y + ph), 0, 0, 0);
            pl.Closed = true;
            pl.Layer = "GR_PRELIM_STONE";
            pl.TransformBy(Matrix3d.Displacement(origin.GetAsVector()));
            pl.TransformBy(e.CurrentUserCoordinateSystem);
            space.AppendEntity(pl);
            tr.AddNewlyCreatedDBObject(pl, true);
        }
        var note = new DBText() { TextString = "GOLDEN ROCK - PRELIMINARY / RFI REQUIRED / NOT FOR FABRICATION", Height = 25, Position = new Point3d(origin.X, origin.Y - 60, origin.Z), Layer = "GR_PRELIM_STONE" };
        note.TransformBy(e.CurrentUserCoordinateSystem);
        space.AppendEntity(note);
        tr.AddNewlyCreatedDBObject(note, true);
    }

    // Shared: draw drawing_package entities (lines/text) plus native AutoCAD dimensions for the panels.
    // Used by GRDETAILS (manual entry) and GRIMPORT (loaded from the website's review JSON).
    void DrawDetailPackage(Transaction tr, Database db, Editor e, Point3d point, Dictionary<string, object> result)
    {
        var drawing = (Dictionary<string, object>)result["drawing_package"];
        var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
        var space = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);
        foreach (Dictionary<string, object> item in (System.Collections.IEnumerable)drawing["entities"])
        {
            string layer = (string)item["layer"];
            if (!lt.Has(layer))
            {
                if (!lt.IsWriteEnabled) lt.UpgradeOpen();
                var lr = new LayerTableRecord() { Name = layer };
                lt.Add(lr);
                tr.AddNewlyCreatedDBObject(lr, true);
            }
            double x = Convert.ToDouble(item["x"]), y = Convert.ToDouble(item["y"]);
            Entity entity;
            if ((string)item["type"] == "LINE")
                entity = new Line(new Point3d(x, y, 0), new Point3d(Convert.ToDouble(item["x2"]), Convert.ToDouble(item["y2"]), 0));
            else
                entity = new DBText() { Position = new Point3d(x, y, 0), Height = Convert.ToDouble(item["height"]), TextString = (string)item["text"] };
            entity.Layer = layer;
            entity.TransformBy(Matrix3d.Displacement(point.GetAsVector()));
            entity.TransformBy(e.CurrentUserCoordinateSystem);
            space.AppendEntity(entity);
            tr.AddNewlyCreatedDBObject(entity, true);
        }
        string dimLayer = "GR_DIMENSIONS";
        if (!lt.Has(dimLayer))
        {
            if (!lt.IsWriteEnabled) lt.UpgradeOpen();
            var lr = new LayerTableRecord() { Name = dimLayer };
            lt.Add(lr);
            tr.AddNewlyCreatedDBObject(lr, true);
        }
        var shop = (Dictionary<string, object>)result["shop_drawing"];
        foreach (Dictionary<string, object> panel in (System.Collections.IEnumerable)shop["panels"])
        {
            double px = Convert.ToDouble(panel["x_mm"]), py = Convert.ToDouble(panel["y_mm"]), pw = Convert.ToDouble(panel["width_mm"]), ph = Convert.ToDouble(panel["height_mm"]);
            if (py == 0)
            {
                var dim = new RotatedDimension(0, new Point3d(px, py, 0), new Point3d(px + pw, py, 0), new Point3d(px, py - 230, 0), "<>", db.Dimstyle);
                dim.Dimtxt = 22; dim.Dimasz = 15; dim.Layer = dimLayer;
                dim.TransformBy(Matrix3d.Displacement(point.GetAsVector()));
                dim.TransformBy(e.CurrentUserCoordinateSystem);
                space.AppendEntity(dim);
                tr.AddNewlyCreatedDBObject(dim, true);
            }
            if (px == 0)
            {
                var dim = new RotatedDimension(Math.PI / 2, new Point3d(px, py, 0), new Point3d(px, py + ph, 0), new Point3d(px - 180, py, 0), "<>", db.Dimstyle);
                dim.Dimtxt = 22; dim.Dimasz = 15; dim.Layer = dimLayer;
                dim.TransformBy(Matrix3d.Displacement(point.GetAsVector()));
                dim.TransformBy(e.CurrentUserCoordinateSystem);
                space.AppendEntity(dim);
                tr.AddNewlyCreatedDBObject(dim, true);
            }
        }
    }

    [CommandMethod("GRWALL")]
    public void Wall()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument; var e = doc.Editor;
        try
        {
            if (doc.Database.Insunits != UnitsValue.Millimeters) throw new System.Exception("Set drawing units to millimetres before using GRWALL.");
            var a = e.GetPoint("\nSelect lower-left corner of rectangular wall ELEVATION: "); if (a.Status != PromptStatus.OK) return;
            var b = e.GetCorner("\nSelect upper-right corner (no openings in this zone): ", a.Value); if (b.Status != PromptStatus.OK) return;
            double w = b.Value.X - a.Value.X, h = b.Value.Y - a.Value.Y; if (w <= 0 || h <= 0) throw new System.Exception("Upper-right point must be above and right of first point.");
            var slabw = Number(e, "\nAvailable slab width mm: "); var slabh = Number(e, "\nAvailable slab height mm: "); var kerf = Number(e, "\nSaw kerf mm: "); var trim = Number(e, "\nSlab edge trim mm: ");
            var thick = Number(e, "\nStone thickness mm (20, 25 or 30): "); if (thick != 20 && thick != 25 && thick != 30) throw new System.Exception("Choose 20, 25 or 30 mm.");
            var input = new
            {
                detail_profile = thick == 25 ? "project_option2_25mm" : thick == 30 ? "project_custom_30mm" : "external_standard_20mm",
                environment = "External",
                element = "Wall Cladding",
                system = "U",
                zone = "AutoCAD rectangular elevation",
                width_mm = w,
                height_mm = h,
                dimensions_verified = true,
                rock_wool = true,
                stone_fixings_per_piece = 4,
                stone_fixing_type = "U_channel",
                material = new { name = "Client selected stone", thickness_mm = thick, slabs = new[] { new { width_mm = slabw, height_mm = slabh } }, kerf_mm = kerf, edge_trim_mm = trim }
            };
            File.WriteAllText(Path.Combine(PluginFolder(), "last-input.json"), json.Serialize(input));
            var result = json.Deserialize<Dictionary<string, object>>(Call("/api/cladding/plan", json.Serialize(input)));
            var shop = (Dictionary<string, object>)result["shop_drawing"];
            var panels = (System.Collections.IEnumerable)shop["panels"];
            string report = Path.Combine(PluginFolder(), "last-review.json"); File.WriteAllText(report, json.Serialize(result));
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                DrawPanels(tr, doc.Database, e, a.Value, panels);
                tr.Commit();
            }
            e.WriteMessage("\nGolden Rock result drawn. Full response and RFIs: " + report + "\nChannel geometry and openings require a separate verified design; not generated by this command.");
        }
        catch (System.Exception ex) { e.WriteMessage("\nGolden Rock: " + ex.Message); }
    }

    [CommandMethod("GRDETAILS")]
    public void Details()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument; var e = doc.Editor;
        try
        {
            if (doc.Database.Insunits != UnitsValue.Millimeters) throw new System.Exception("Drawing units must be millimetres.");
            string folder = PluginFolder();
            var filePrompt = new PromptStringOptions("\nInput JSON path (choose segment-N-input.json for scan details): ") { AllowSpaces = true };
            var fileResult = e.GetString(filePrompt);
            if (fileResult.Status != PromptStatus.OK || string.IsNullOrWhiteSpace(fileResult.StringResult)) return;
            string path = fileResult.StringResult.Trim().Trim('"');
            if (!File.Exists(path)) throw new System.Exception("Run GRWALL (or GRIMPORT) with this updated plugin first.");
            var input = json.Deserialize<Dictionary<string, object>>(File.ReadAllText(path));
            var mod = new PromptKeywordOptions("\nWall module 800-1000mm [Yes/No] <Yes>: "); mod.Keywords.Add("Yes"); mod.Keywords.Add("No"); mod.AllowNone = true;
            var mr = e.GetKeywords(mod); if (mr.Status == PromptStatus.Cancel) return;
            if (mr.StringResult != "No")
            {
                double min = Number(e, "\nPreferred minimum stone width mm (example 800): ");
                double max = Number(e, "\nPreferred maximum stone width mm (example 1000): ");
                double offset = Number(e, "\nChannel centre-line offset from stone edge mm (design input): ");
                input["wall_module"] = new { preferred_min_mm = min, preferred_max_mm = max, channel_edge_offset_mm = offset };
            }
            var opt = new PromptKeywordOptions("\nChannel coordinates [Enter/Skip] <Skip>: "); opt.Keywords.Add("Enter"); opt.Keywords.Add("Skip"); opt.AllowNone = true;
            var choice = e.GetKeywords(opt); if (choice.Status == PromptStatus.Cancel) return;
            if (choice.StringResult == "Enter")
            {
                input["channel_layout"] = new
                {
                    x_positions_mm = Numbers(e, "\nChannel X positions (comma separated): "),
                    base_y_mm = ZeroNumber(e, "\nChannel base Y mm: "),
                    large_bracket_levels_mm = Numbers(e, "\nFour large bracket levels from base (comma separated): "),
                    small_bracket_levels_mm = Numbers(e, "\nFour reverse bracket levels from base (comma separated): ")
                };
            }
            var result = json.Deserialize<Dictionary<string, object>>(Call("/api/cladding/plan", json.Serialize(input)));
            if (!result.ContainsKey("drawing_package")) throw new System.Exception("Server update v1.3 is required before GRDETAILS can draw details.");
            var point = e.GetPoint("\nSelect insertion point for separate review drawing package: "); if (point.Status != PromptStatus.OK) return;
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                DrawDetailPackage(tr, doc.Database, e, point.Value, result);
                tr.Commit();
            }
            File.WriteAllText(Path.Combine(folder, "last-detail-review.json"), json.Serialize(result));
            e.WriteMessage("\nReview sheets drawn. Read last-detail-review.json for RFIs. Openings/structural design remain unverified. NOT FOR FABRICATION.");
        }
        catch (System.Exception ex) { e.WriteMessage("\nGolden Rock: " + ex.Message); }
    }

    // NEW in this build: reads the SOLID WALL and OPENING geometry straight from the current
    // drawing (by color) instead of the drafter re-typing/re-measuring each wall segment by hand,
    // and folds in the confirmed connection-geometry formula (support face + projection - stone
    // penetration = stone back) so that distance no longer needs recalculating for every wall.
    // Nothing is guessed: the two color samples, the facade window, and every fabrication/
    // connection value are picked or confirmed by the drafter, with project-confirmed figures
    // offered only as an editable default, never a silent assumption.
    [CommandMethod("GRSCAN")]
    public void Scan()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument; var e = doc.Editor; var db = doc.Database;
        try
        {
            if (db.Insunits != UnitsValue.Millimeters) throw new System.Exception("Set drawing units to millimetres before using GRSCAN.");
            if (!e.CurrentUserCoordinateSystem.Equals(Matrix3d.Identity)) throw new System.Exception("GRSCAN currently requires World UCS.");

            var wallPick = e.GetEntity("\nSelect one sample object with the SOLID WALL color: ");
            if (wallPick.Status != PromptStatus.OK) return;
            Color wallColor;
            using (var tr0 = db.TransactionManager.StartTransaction())
            {
                var ent = (Entity)tr0.GetObject(wallPick.ObjectId, OpenMode.ForRead);
                wallColor = EffectiveColor(tr0, ent);
                tr0.Commit();
            }

            bool hasOpenings = true;
            Color openingColor = wallColor;
            var openPick = e.GetEntity("\nSelect one sample object with the OPENING (door/window) color, or press Escape if this facade has no openings: ");
            if (openPick.Status != PromptStatus.OK) { hasOpenings = false; }
            else
            {
                using (var tr0 = db.TransactionManager.StartTransaction())
                {
                    var ent = (Entity)tr0.GetObject(openPick.ObjectId, OpenMode.ForRead);
                    openingColor = EffectiveColor(tr0, ent);
                    tr0.Commit();
                }
            }

            var a = e.GetPoint("\nSelect lower-left corner of a window enclosing the WHOLE facade (wall plus openings): ");
            if (a.Status != PromptStatus.OK) return;
            var b = e.GetCorner("\nSelect upper-right corner: ", a.Value);
            if (b.Status != PromptStatus.OK) return;

            double envLeft = Math.Min(a.Value.X, b.Value.X), envRight = Math.Max(a.Value.X, b.Value.X);
            double envBottom = Math.Min(a.Value.Y, b.Value.Y), envTop = Math.Max(a.Value.Y, b.Value.Y);

            var openingRanges = new List<double[]>();
            bool wallFound = false;

            using (var tr = db.TransactionManager.StartTransaction())
            {
                var psr = e.SelectCrossingWindow(new Point3d(envLeft, envBottom, 0), new Point3d(envRight, envTop, 0));
                if (psr.Status == PromptStatus.OK)
                {
                    foreach (SelectedObject so in psr.Value)
                    {
                        Entity ent;
                        try { ent = (Entity)tr.GetObject(so.ObjectId, OpenMode.ForRead); } catch { continue; }
                        if (!(ent is Polyline) || !((Polyline)ent).Closed || ent.Color.ColorMethod == ColorMethod.ByBlock) throw new System.Exception("RFI_REQUIRED: scan requires closed polylines; blocks/lines are unsupported. Prepare explicit wall/opening boundaries.");
                        Color c;
                        try { c = EffectiveColor(tr, ent); } catch { continue; }
                        if (hasOpenings && SameColor(wallColor, openingColor)) throw new System.Exception("Wall and opening colors must differ.");
                        if (SameColor(c, wallColor) || (hasOpenings && SameColor(c, openingColor))) {
                            var poly = (Polyline)ent;
                            if (poly.NumberOfVertices != 4) throw new System.Exception("RFI_REQUIRED: only four-corner rectangles are supported.");
                            for (int vi=0; vi<4; vi++) {
                                var v1=poly.GetPoint2dAt(vi); var v2=poly.GetPoint2dAt((vi+1)%4);
                                if (Math.Abs(poly.GetBulgeAt(vi))>0.000001 || (Math.Abs(v1.X-v2.X)>0.01 && Math.Abs(v1.Y-v2.Y)>0.01))
                                    throw new System.Exception("RFI_REQUIRED: curved or rotated boundaries are unsupported.");
                            }
                        }
                        if (SameColor(c, wallColor)) {
                            if (wallFound) throw new System.Exception("Select one wall boundary per scan.");
                            var bounds=ent.GeometricExtents;
                            if (Math.Abs(bounds.MinPoint.X-envLeft)>0.01 || Math.Abs(bounds.MaxPoint.X-envRight)>0.01 || Math.Abs(bounds.MinPoint.Y-envBottom)>0.01 || Math.Abs(bounds.MaxPoint.Y-envTop)>0.01)
                                throw new System.Exception("Snap selection corners to the actual wall boundary; selection margins are not wall dimensions.");
                            wallFound = true;
                        }
                        if (hasOpenings && SameColor(c, openingColor))
                        {
                            try
                            {
                                var ext = ent.GeometricExtents;
                                if (ext.MinPoint.Y > envBottom + 0.01 || ext.MaxPoint.Y < envTop - 0.01) throw new System.Exception("RFI_REQUIRED: partial-height openings require separate head/sill zones; this scan cannot process them.");
                                openingRanges.Add(new double[] { Math.Max(envLeft,ext.MinPoint.X), Math.Min(envRight,ext.MaxPoint.X) });
                            }
                            catch (System.Exception ex) { throw new System.Exception("Opening geometry invalid: " + ex.Message); }
                        }
                    }
                }
                tr.Commit();
            }
            if (!wallFound) throw new System.Exception("No object matching the wall color was found inside the selected window. Pick the wall-color sample again or widen the window.");

            openingRanges.Sort((r1, r2) => r1[0].CompareTo(r2[0]));
            var merged = new List<double[]>();
            foreach (var r in openingRanges)
            {
                if (merged.Count > 0 && r[0] <= merged[merged.Count - 1][1])
                    merged[merged.Count - 1][1] = Math.Max(merged[merged.Count - 1][1], r[1]);
                else
                    merged.Add(new double[] { r[0], r[1] });
            }

            var segments = new List<double[]>();
            double cursor = envLeft;
            foreach (var m in merged)
            {
                if (m[0] - cursor > 1.0) segments.Add(new double[] { cursor, m[0] });
                cursor = Math.Max(cursor, m[1]);
            }
            if (envRight - cursor > 1.0) segments.Add(new double[] { cursor, envRight });
            if (segments.Count == 0) throw new System.Exception("No solid wall segment remains after removing openings - check the window and the two color samples.");

            e.WriteMessage("\nGolden Rock: " + segments.Count + " solid segment(s) and " + merged.Count + " opening(s) found by color.");

            var slabw = Number(e, "\nAvailable slab width mm: ");
            var slabh = Number(e, "\nAvailable slab height mm: ");
            var kerf = Number(e, "\nSaw kerf mm: ");
            var trim = Number(e, "\nSlab edge trim mm: ");
            var thick = Number(e, "\nStone thickness mm (20, 25 or 30): ");
            if (thick != 20 && thick != 25 && thick != 30) throw new System.Exception("Choose 20, 25 or 30 mm.");

            var sysOpt = new PromptKeywordOptions("\nFixing system [U/Z/Omega/L] <U>: ");
            sysOpt.Keywords.Add("U"); sysOpt.Keywords.Add("Z"); sysOpt.Keywords.Add("Omega"); sysOpt.Keywords.Add("L");
            sysOpt.AllowNone = false;
            var sysR = e.GetKeywords(sysOpt); if (sysR.Status == PromptStatus.Cancel) return;
            if (sysR.Status != PromptStatus.OK) throw new System.Exception("Select system explicitly.");
            string system = sysR.StringResult == "Omega" ? "OMEGA" : sysR.StringResult;

            double fixings = Number(e, "\nFixings per stone piece (3 or 4) - type the value explicitly: ");
            if (fixings != 3 && fixings != 4) throw new System.Exception("Choose 3 or 4 fixings per piece.");
            string threePointSide = null;
            if (system == "L" && fixings == 3)
            {
                var sideOpt = new PromptKeywordOptions("\nWhich side keeps the pair of brackets [Top/Bottom] (no safe default): ");
                sideOpt.Keywords.Add("Top"); sideOpt.Keywords.Add("Bottom");
                var sideR = e.GetKeywords(sideOpt); if (sideR.Status != PromptStatus.OK) throw new System.Exception("3-fixing arrangement needs an explicit side - there is no safe default.");
                threePointSide = sideR.StringResult.ToLowerInvariant();
            }

            double defaultProjection = system == "L" ? 50 : 40;
            e.WriteMessage("\nNo connection value is assumed. Reference values 110mm and " + defaultProjection.ToString("0") + "mm are shown for review only.");
            double cavity = Number(e, "\nSupport face distance from wall mm - confirm for this project: ");
            double projection = Number(e, "\nScrew/pin projection from support face mm - confirm for this project: ");
            double penetration;
            if (thick == 20) penetration = Number(e, "\nStone penetration depth mm - confirm (reference 8mm, no default): ");
            else if (thick == 30) penetration = Number(e, "\nStone penetration depth mm - confirm (reference 14mm, no default): ");
            else penetration = Number(e, "\n25mm stone penetration depth mm (not yet confirmed for this project - RFI, no default): ");

            if (penetration >= thick || penetration > projection) throw new System.Exception("Penetration conflicts with thickness/projection.");
            if (projection != defaultProjection || (thick == 20 && penetration != 8) || (thick == 30 && penetration != 14) || thick == 25 || (system == "U" && cavity != 110))
                throw new System.Exception("RFI_REQUIRED: connection differs from backend contract. No request sent.");
            double stoneBack = cavity + projection - penetration;
            var confirm = new PromptKeywordOptions("\nConfirm geometry and preliminary-only use [Yes/No]: ");
            confirm.Keywords.Add("Yes"); confirm.Keywords.Add("No"); confirm.AllowNone = false;
            if (e.GetKeywords(confirm).StringResult != "Yes") return;
            e.WriteMessage("\nGolden Rock: support face " + cavity + "mm, stone back " + stoneBack + "mm, finished face " + (stoneBack + thick) + "mm from wall.");

            var allResults = new List<object>();
            var pendingResults = new List<Dictionary<string, object>>();
            string runFolder = Path.Combine(PluginFolder(), "runs", DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(runFolder);
            int segIndex = 0;
            foreach (var seg in segments)
            {
                segIndex++;
                double w = seg[1] - seg[0], h = envTop - envBottom;
                object bracketLayout = threePointSide != null ? (object)new { three_point_side = threePointSide } : null;
                var input = new
                {
                    detail_profile = thick == 25 ? "project_option2_25mm" : thick == 30 ? "project_custom_30mm" : "external_standard_20mm",
                    environment = "External",
                    element = "Wall Cladding",
                    system = system,
                    zone = "AutoCAD GRSCAN segment " + segIndex,
                    width_mm = w,
                    height_mm = h,
                    dimensions_verified = true,
                    rock_wool = true,
                    stone_fixings_per_piece = fixings,
                    stone_fixing_type = system == "U" ? "U_channel" : (system == "OMEGA" ? "Omega_bracket" : system + "_bracket"),
                    bracket_layout = bracketLayout,
                    connection = new { entry = "rear", support_face_from_wall_mm = cavity, stone_back_from_wall_mm = stoneBack },
                    material = new { name = "Client selected stone", thickness_mm = thick, slabs = new[] { new { width_mm = slabw, height_mm = slabh } }, kerf_mm = kerf, edge_trim_mm = trim }
                };
                string inputJson = json.Serialize(input);
                File.WriteAllText(Path.Combine(runFolder, "segment-" + segIndex + "-input.json"), inputJson);
                var result = json.Deserialize<Dictionary<string, object>>(Call("/api/cladding/plan", inputJson));
                allResults.Add(new Dictionary<string, object> { { "segment_index", segIndex }, { "x_min_mm", seg[0] }, { "x_max_mm", seg[1] }, { "result", result } });

                pendingResults.Add(result);
                File.WriteAllText(Path.Combine(runFolder, "segment-" + segIndex + "-review.json"), json.Serialize(result));
            }
            // Fetch every segment before one transaction: any failure leaves no partial drawing.
            using (var tr = db.TransactionManager.StartTransaction())
            {
                for (int i = 0; i < pendingResults.Count; i++) {
                    var shop = (Dictionary<string, object>)pendingResults[i]["shop_drawing"];
                    DrawPanels(tr, db, e, new Point3d(segments[i][0], envBottom, 0), (System.Collections.IEnumerable)shop["panels"]);
                }
                tr.Commit();
            }
            File.WriteAllText(Path.Combine(runFolder, "complete.json"), json.Serialize(allResults));

            string archive = Path.Combine(PluginFolder(), "scan-review-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".json");
            File.WriteAllText(archive, json.Serialize(allResults));
            File.WriteAllText(Path.Combine(PluginFolder(), "last-scan-review.json"), json.Serialize(allResults));
            e.WriteMessage("\nGolden Rock: " + segments.Count + " segment(s) sent to the server and drawn. Full results: last-scan-review.json.");
            e.WriteMessage("\nPRELIMINARY - NOT FOR FABRICATION. Run GRDETAILS for channel/bracket setting-out (select the archived segment input JSON); re-run it per segment if you need detail sheets for more than one.");
        }
        catch (System.Exception ex) { e.WriteMessage("\nGolden Rock: " + ex.Message); }
    }

    // NEW in this build: instead of re-typing wall/material/fixing data by hand in AutoCAD,
    // read the review JSON already downloaded from the website (Calculate/Refresh -> Download)
    // and draw straight from it.
    [CommandMethod("GRIMPORT")]
    public void Import()
    {
        var doc = AcApp.DocumentManager.MdiActiveDocument; var e = doc.Editor;
        try
        {
            if (doc.Database.Insunits != UnitsValue.Millimeters) throw new System.Exception("Set drawing units to millimetres before using GRIMPORT.");

            string suggested = FindNewestDownload();
            string prompt = suggested != null
                ? "\nPath to the review JSON downloaded from the website <" + suggested + ">: "
                : "\nPath to the review JSON downloaded from the website: ";
            var po = new PromptStringOptions(prompt) { AllowSpaces = true };
            var pr = e.GetString(po);
            if (pr.Status != PromptStatus.OK) return;
            string filePath = string.IsNullOrEmpty(pr.StringResult.Trim()) ? suggested : pr.StringResult.Trim().Trim('"');
            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
                throw new System.Exception("File not found: " + filePath);

            var result = json.Deserialize<Dictionary<string, object>>(File.ReadAllText(filePath));
            if (!result.ContainsKey("shop_drawing"))
                throw new System.Exception("This does not look like a Golden Rock review file (no shop_drawing section).");

            if (result.ContainsKey("input"))
                File.WriteAllText(Path.Combine(PluginFolder(), "last-input.json"), json.Serialize(result["input"]));
            File.WriteAllText(Path.Combine(PluginFolder(), "last-review.json"), json.Serialize(result));

            var shop = (Dictionary<string, object>)result["shop_drawing"];
            var panels = (System.Collections.IEnumerable)shop["panels"];
            int panelCount = 0;
            foreach (object p in panels) panelCount++;

            if (panelCount == 0)
            {
                string openRfis = "";
                if (result.ContainsKey("rfis"))
                {
                    int rfiCount = 0;
                    var examples = new List<string>();
                    foreach (Dictionary<string, object> r in (System.Collections.IEnumerable)result["rfis"])
                    {
                        if (r.ContainsKey("status") && (string)r["status"] == "RFI_REQUIRED")
                        {
                            rfiCount++;
                            if (examples.Count < 3) examples.Add((string)r["message"]);
                        }
                    }
                    openRfis = "\n" + rfiCount + " open RFI(s), for example: " + string.Join("; ", examples.ToArray());
                }
                e.WriteMessage("\nNo panels to draw yet - this file has no calculated layout." + openRfis +
                    "\nResolve the RFIs on the website, recalculate, and download the JSON again before importing.");
                return;
            }

            var a = e.GetPoint("\nSelect insertion point for the stone panel layout: "); if (a.Status != PromptStatus.OK) return;
            using (var tr = doc.Database.TransactionManager.StartTransaction())
            {
                DrawPanels(tr, doc.Database, e, a.Value, panels);
                tr.Commit();
            }
            e.WriteMessage("\nGolden Rock: " + panelCount + " panel(s) drawn from " + Path.GetFileName(filePath) + ".");

            if (result.ContainsKey("drawing_package"))
            {
                var drawing = (Dictionary<string, object>)result["drawing_package"];
                int entityCount = 0;
                if (drawing.ContainsKey("entities"))
                    foreach (object item in (System.Collections.IEnumerable)drawing["entities"]) entityCount++;
                if (entityCount > 0)
                {
                    var dp = e.GetPoint("\nSelect insertion point for the review drawing package (Escape to skip): ");
                    if (dp.Status == PromptStatus.OK)
                    {
                        using (var tr = doc.Database.TransactionManager.StartTransaction())
                        {
                            DrawDetailPackage(tr, doc.Database, e, dp.Value, result);
                            tr.Commit();
                        }
                        e.WriteMessage("\nGolden Rock: review drawing package drawn.");
                    }
                }
            }
            e.WriteMessage("\nPRELIMINARY - NOT FOR FABRICATION. Review remaining RFIs in the imported file.");
        }
        catch (System.Exception ex) { e.WriteMessage("\nGolden Rock: " + ex.Message); }
    }

    static string FindNewestDownload()
    {
        try
        {
            string downloads = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            if (!Directory.Exists(downloads)) return null;
            string best = null;
            DateTime bestTime = DateTime.MinValue;
            foreach (string file in Directory.GetFiles(downloads, "*.json"))
            {
                string name = Path.GetFileName(file).ToLowerInvariant();
                if (name.Contains("golden") || name.Contains("review"))
                {
                    DateTime t = File.GetLastWriteTimeUtc(file);
                    if (best == null || t > bestTime) { best = file; bestTime = t; }
                }
            }
            return best;
        }
        catch { return null; }
    }
}
